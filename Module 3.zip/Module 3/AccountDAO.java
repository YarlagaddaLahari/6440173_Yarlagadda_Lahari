import java.sql.*;

public class AccountDAO {
    private Connection conn;
    public AccountDAO(Connection conn) {
        this.conn = conn;
    }
    public void transfer(int fromId, int toId, double amount) throws SQLException {
        try {
            conn.setAutoCommit(false); 
            PreparedStatement debitStmt = conn.prepareStatement("UPDATE accounts SET balance = balance - ? WHERE id = ?");
            debitStmt.setDouble(1, amount);
            debitStmt.setInt(2, fromId);
            int rowsUpdated1 = debitStmt.executeUpdate();
            PreparedStatement creditStmt = conn.prepareStatement("UPDATE accounts SET balance = balance + ? WHERE id = ?");
            creditStmt.setDouble(1, amount);
            creditStmt.setInt(2, toId);
            int rowsUpdated2 = creditStmt.executeUpdate();
            if (rowsUpdated1 == 1 && rowsUpdated2 == 1) {
                conn.commit();
                System.out.println("Transfer successful!");
            } else {
                conn.rollback();
                System.out.println("Transfer failed, rolled back.");
            }
        } catch (SQLException e) {
            conn.rollback();
            throw e; 
        } finally {
            conn.setAutoCommit(true);         }
    }
    public void printBalances() throws SQLException {
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT id, name, balance FROM accounts");
        while (rs.next()) {
            System.out.println(
                rs.getInt("id") + ": " +
                rs.getString("name") + " - " +
                rs.getDouble("balance"));
        }
    }
}
