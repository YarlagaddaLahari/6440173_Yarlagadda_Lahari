public class PatternMatching {
    public static void checkType(Object obj) {
        if (obj instanceof Integer) {
            System.out.println("It's an Integer: " + obj);
        } else if (obj instanceof String) {
            System.out.println("It's a String: " + obj);
        } else if (obj instanceof Double) {
            System.out.println("It's a Double: " + obj);
        } else {
            System.out.println("Unknown type");
        }
    }
    public static void main(String[] args) {
        checkType(123);
        checkType("Hello");
        checkType(3.14);
        checkType(true);
    }
}
