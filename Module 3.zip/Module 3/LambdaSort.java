import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LambdaSort {
    public static void main(String[] args) {
        List<String> str = new ArrayList<>();
        str.add("Sam");
        str.add("Vam");
        str.add("Ram");
        Collections.sort(str, (a, b) -> a.compareTo(b));
        System.out.println("Sorted list: " + str);
    }
}
