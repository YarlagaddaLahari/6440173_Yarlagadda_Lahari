import java.net.*;
import java.io.*;

public class Client {
    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 12345);

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

        BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));
        String line;

        while ((line = keyboard.readLine()) != null) {
            out.println(line);
            String response = in.readLine();
            System.out.println("Server: " + response);
        }
        socket.close();
    }
}
