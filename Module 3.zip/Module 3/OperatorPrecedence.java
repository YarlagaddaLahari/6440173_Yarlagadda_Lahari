public class OperatorPrecedence {
    public static void main(String[] args) {
        int res1 = 8 + 3 * 4;
        int res2 = (8 + 3) * 4;
        int res3 = 15 - 4 + 2;
        int res4 = 24 / 6 * 3;
        System.out.println("Result 1 (8 + 3 * 4): " + res1);
        System.out.println("Result 2 ((8 + 3) * 4): " + res2);
        System.out.println("Result 3 (15 - 4 + 2): " + res3);
        System.out.println("Result 4 (24 / 6 * 3): " + res4);
    }
}
