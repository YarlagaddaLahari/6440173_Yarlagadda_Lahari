import java.util.Scanner;

public class StringReversal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String a = sc.nextLine();
        String res = "";
        for (int i = a.length() - 1; i >= 0; i--) {
            res += a.charAt(i);
        }
        System.out.println("Reversed string: " + res);
        sc.close();
    }
}
