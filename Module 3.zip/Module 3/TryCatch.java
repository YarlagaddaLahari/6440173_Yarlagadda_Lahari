import java.util.Scanner;

public class TryCatch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter first integer: ");
        int n1 = sc.nextInt();
        System.out.print("Enter second integer: ");
        int n2 = sc.nextInt();
        try {
            int res = n1 / n2;
            System.out.println("Result: " + res);
        } catch (ArithmeticException e) {
            System.out.println("Zero Division is not possible");
        }
        sc.close();
    }
}
