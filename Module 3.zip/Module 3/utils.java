module-info.java in com.utils:
module com.utils {
    exports com.utils;
}


package com.utils;

public class Utils {
    public static String getGreeting(String name) {
        return "Hello, " + name + "!";
    }
}
