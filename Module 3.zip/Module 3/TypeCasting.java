public class TypeCasting {
    public static void main(String[] args) {
        double n1 = 45.67;
        int n2 = (int) n1;
        System.out.println("Original double value: " + n1);
        System.out.println("Explicit Type Casting : " + n2);
        int n3 = 25;
        double n4 = n3;
        System.out.println("Original int value: " + n3);
        System.out.println("Implicit Type Casting : " + n4);
    }
}
