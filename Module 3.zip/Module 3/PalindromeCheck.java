import java.util.Scanner;

public class PalindromeCheck {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String txt = sc.nextLine();
        String str = "";
        for (int i = 0; i < txt.length(); i++) {
            char c = txt.charAt(i);
            if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9')) {
                if (c >= 'A' && c <= 'Z') {
                    c = (char)(c + 32);
                }
                str = str + c;
            }
        }
        boolean palindrome = true;
        int left = 0;
        int right = str.length() - 1;

        while (left < right) {
            if (str.charAt(left) != str.charAt(right)) {
                palindrome = false;
                break;
            }
            left++;
            right--;
        }
        if (palindrome) {
            System.out.println(txt + " is a palindrome.");
        } else {
            System.out.println(txt + " is not a palindrome.");
        }

        sc.close();
    }
}
