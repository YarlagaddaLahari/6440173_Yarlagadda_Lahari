import java.sql.*;

public class MainApp2 {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/your_db_name";
        String user = "lahari";
        String password = "Cambridge@728";
        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            AccountDAO dao = new AccountDAO(conn);
            System.out.println("Balances before transfer:");
            dao.printBalances();
            dao.transfer(1, 2, 100.00); 
           System.out.println("Balances after transfer:");
            dao.printBalances();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
