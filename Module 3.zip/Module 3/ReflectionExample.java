import java.lang.reflect.*;

public class ReflectionExample {
    public void hello(String name) {
        System.out.println("Hello, " + name);
    }

    public static void main(String[] args) throws Exception {
        Class<?> cls = Class.forName("ReflectionExample");
        Method[] methods = cls.getDeclaredMethods();

        for (Method m : methods) {
            System.out.println("Method: " + m.getName());
            Class<?>[] params = m.getParameterTypes();
            System.out.print("Parameters: ");
            for (Class<?> p : params) {
                System.out.print(p.getName() + " ");
            }
            System.out.println();
        }

        Object obj = cls.getDeclaredConstructor().newInstance();
        Method helloMethod = cls.getMethod("hello", String.class);
        helloMethod.invoke(obj, "World");
    }
}
