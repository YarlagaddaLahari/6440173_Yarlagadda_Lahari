public class DataTypeDemo {
    public static void main(String[] args) {
        int a = 7;
        float b = 3.14f;
        double c = 21.7;
        char d = 'A';
        boolean e = true;
        System.out.println("Integer value: " + a);
        System.out.println("Float value: " + b);
        System.out.println("Double value: " + c);
        System.out.println("Character value: " + d);
        System.out.println("Boolean value: " + e);
    }
}
