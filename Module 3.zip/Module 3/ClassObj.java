public class ClassObj {
    String brand;
    String type;
    int Year;
    void displayDetails() {
        System.out.println("Brand: " + brand);
        System.out.println("Model: " + type);
        System.out.println("Year: " + Year);
    }
    public static void main(String[] args) {
        ClassObj car1 = new ClassObj();
        car1.brand = "Hyundai";
        car1.type = "i20";
        car1.Year = 2019;
        ClassObj car2 = new ClassObj();
        car2.brand = "Tata";
        car2.type = "Indica";
        car2.Year = 2015;
        car1.displayDetails();
        System.out.println();
        car2.displayDetails();
        System.out.println();
    }
}
