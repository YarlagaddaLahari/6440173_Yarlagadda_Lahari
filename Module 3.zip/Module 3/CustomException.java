import java.util.Scanner;

class Age extends Exception {
    Age() {}
}
public class CustomException {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your age: ");
        int age = sc.nextInt();
        try {
            if (age < 18) {
                throw new Age();
            } else {
                System.out.println("Age is valid.");
            }
        } catch (Age e) {
            System.out.println("Age must be less than or equal to 18");
        }
        sc.close();
    }
}
