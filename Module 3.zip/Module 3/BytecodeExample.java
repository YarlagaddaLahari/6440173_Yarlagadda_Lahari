public class BytecodeExample {
    public void greet() {
        System.out.println("Hello Bytecode!");
    }
}
