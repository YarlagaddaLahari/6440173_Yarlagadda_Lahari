public class SimpleClass {
    public void sayHi() {
        System.out.println("Hi!");
    }
}
