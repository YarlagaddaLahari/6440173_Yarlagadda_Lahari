import java.util.HashMap;
import java.util.Scanner;

public class HashMapExample {
    public static void main(String[] args) {
        HashMap<Integer, String> students = new HashMap<>();
        Scanner input = new Scanner(System.in);

        System.out.print("How many students do you want to add? ");
        int count = input.nextInt();
        input.nextLine(); // clear newline

        for (int i = 0; i < count; i++) {
            System.out.print("Enter student ID: ");
            int id = input.nextInt();
            input.nextLine(); // clear newline

            System.out.print("Enter student name: ");
            String name = input.nextLine();

            students.put(id, name);
        }

        System.out.print("Enter an ID to find the student name: ");
        int searchId = input.nextInt();

        if (students.containsKey(searchId)) {
            System.out.println("Name: " + students.get(searchId));
        } else {
            System.out.println("Student not found.");
        }

        input.close();
    }
}
