public class MainApp {
    public static void main(String[] args) {
        try {
            StudentDAO dao = new StudentDAO();
            dao.insertStudent(1, "Ria");
            dao.insertStudent(2, "Dev");
            dao.updateStudent(1, "Ria Updated");
            dao.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
