// main.js

console.log("Welcome to the Community Portal");

window.onload = function () {
  alert("Page fully loaded!");
  const saved = localStorage.getItem('eventPreference');
  if (saved) document.getElementById('preferredEvent').value = saved;
};

// Event class and data
class Event {
  constructor(name, date, category, seats) {
    this.name = name;
    this.date = new Date(date);
    this.category = category;
    this.seats = seats;
  }

  checkAvailability() {
    return this.seats > 0 && this.date > new Date();
  }
}

Event.prototype.getSummary = function () {
  return `${this.name} on ${this.date.toDateString()} (${this.seats} seats left)`;
};

const events = [
  new Event("Jazz Night", "2025-06-15", "music", 30),
  new Event("Painting Expo", "2025-05-01", "art", 0),
  new Event("Food Carnival", "2025-07-10", "food", 25)
];

// Display only valid events
function displayUpcomingEvents() {
  const list = document.createElement("ul");
  events.forEach(evt => {
    if (evt.checkAvailability()) {
      const item = document.createElement("li");
      item.textContent = evt.getSummary();
      list.appendChild(item);
    }
  });
  document.getElementById("events").appendChild(list);
}

try {
  displayUpcomingEvents();
} catch (err) {
  console.error("Error displaying events:", err);
}

// Closure: count registrations per category
function categoryCounter() {
  const counts = {};
  return function (category) {
    counts[category] = (counts[category] || 0) + 1;
    console.log(`Total registrations for ${category}: ${counts[category]}`);
  };
}

const trackCategory = categoryCounter();

// Example filter using higher-order function
function filterEvents(callback) {
  return events.filter(callback);
}

const musicEvents = filterEvents(e => e.category === "music");
console.log("Filtered Music Events:", musicEvents.map(e => e.name));

// Form handling
document.querySelector("form").addEventListener("submit", function (e) {
  e.preventDefault();
  const name = this.elements.name.value;
  const email = this.elements.email.value;
  const eventType = this.elements.eventType.value;

  if (!name || !email || !eventType) {
    alert("Please fill out all required fields.");
    return;
  }

  trackCategory(eventType); // closure in action

  const userData = {
    name,
    email,
    eventType
  };

  // Simulate async POST
  document.getElementById('confirmation').textContent = "Registering...";

  fetch("https://jsonplaceholder.typicode.com/posts", {
    method: "POST",
    body: JSON.stringify(userData),
    headers: { "Content-type": "application/json; charset=UTF-8" }
  })
    .then(res => res.json())
    .then(data => {
      setTimeout(() => {
        document.getElementById('confirmation').textContent = "Thank you for registering!";
        console.log("Submitted data:", data);
      }, 1000);
    })
    .catch(err => {
      console.error("Registration failed:", err);
      document.getElementById('confirmation').textContent = "Submission failed.";
    });
});
