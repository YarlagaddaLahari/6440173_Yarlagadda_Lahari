const express = require('express');
const mysql = require('mysql2');

const app = express();
const port = 3000;

// Connect to MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'lahari',
  password: 'XXXX',
  database: 'community_events'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

// Root route
app.get('/', (req, res) => {
  res.send('Welcome to the Community Events API');
});

// API endpoint to get upcoming events
app.get('/api/upcoming-events', (req, res) => {
  const query = "SELECT title, start_date, city FROM Events WHERE status = 'upcoming' ORDER BY start_date";
  db.query(query, (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
